import json, sys, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from src import pipeline

class PipelineContractTests(unittest.TestCase):
    def test_each_performance_has_dataset_and_timepoint_role(self):
        self.assertTrue(all(m.get("dataset_role") and m.get("timepoint_role") for m in pipeline.performance_rows()))
    def test_long_metric_rows_have_required_provenance_columns(self):
        for row in pipeline.metric_rows():
            self.assertTrue(all(row.get(k) for k in ("study_id","model_id","dataset_role","timepoint_role","metric","value","source_section","source_identifier")))
    def test_endpoint_definitions_present(self):
        self.assertTrue(all(p.get("endpoint_definition") not in (None,"NR","") for p in pipeline.PAPERS))
    def test_auc_provenance_present(self):
        auc={r["variable"] for r in pipeline.provenance_rows() if r["variable"].startswith("AUC:")}
        self.assertEqual(len(auc),sum(len(p["performance"]) for p in pipeline.PAPERS))
    def test_no_pooling_when_endpoint_or_timepoint_are_incompatible(self):
        self.assertEqual(len({p["endpoint"] for p in pipeline.PAPERS}),3)
        result=pipeline.freeze_synthesis()
        self.assertEqual(result["poolability"],"not justified")
        self.assertFalse(result["pooling_performed"])
        self.assertFalse(result["forest_plot_produced"])
        self.assertIn("timepoint",result["poolability_reason"])
    def test_discordance_and_missing_critical_value_review_required(self):
        self.assertTrue(any(x["status"]=="REVIEW_REQUIRED" for x in pipeline.validation_rows()))
    def test_synthesis_freeze_precedes_benchmark(self):
        result=pipeline.freeze_synthesis()
        self.assertTrue(result["primary_synthesis_frozen"])
        self.assertFalse(result["benchmark_consulted"])
    def test_nr_is_not_numeric(self):
        for row in pipeline.performance_rows():
            if row.get("AUC")=="NR": self.assertEqual(row["AUC"],"NR")
    def test_no_incremental_calculation_without_comparator(self):
        rows=pipeline.incremental_rows()
        for row in rows:
            if row["model_a"]=="NR" or row["model_b"]=="NR":
                self.assertEqual(row["delta_AUC"],"NR")
                self.assertEqual(row["classification"],"Indeterminate")
    def test_unverified_statistical_contrast_is_not_called_suggestive(self):
        rows=pipeline.incremental_rows()
        yang_early=next(r for r in rows if r["study_id"]=="YANG_2022" and r["comparison"].startswith("D ") and r["dataset_role"]=="training")
        yang_delta=next(r for r in rows if r["study_id"]=="YANG_2022" and r["comparison"].startswith("E ") and r["dataset_role"]=="training")
        self.assertEqual(yang_early["classification"],"Indeterminate")
        self.assertEqual(yang_delta["classification"],"Not demonstrated")
    def test_wang_validation_comparisons_preserve_missing_effect_size(self):
        rows=pipeline.incremental_rows()
        combined=next(r for r in rows if r["study_id"]=="WANG_2025" and r["comparison"].startswith("C ") and r["dataset_role"]=="internal_validation")
        self.assertEqual(combined["classification"],"Suggestive")
        self.assertEqual(combined["delta_AUC"],"NR")
        self.assertIn("0.006",combined["statistical_comparison"])

if __name__=="__main__": unittest.main()
