import csv
import hashlib
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/"outputs"


def rows(name):
    with (OUT/name).open(encoding="utf-8",newline="") as f:
        return list(csv.DictReader(f))


class SemanticComparabilityAuditTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.detail=rows("comparability_detailed.csv")

    def pair(self,a,b,criterion):
        return next(r for r in self.detail if (r["study_a"],r["study_b"],r["criterion"])==(a,b,criterion))

    def test_lexically_different_breast_cancer_nac_populations_are_not_automatically_mismatched(self):
        self.assertEqual(self.pair("YANG_2022","WU_2025","population")["status"],"partially_aligned")

    def test_generic_nac_and_invasive_carcinoma_nac_are_at_least_partially_aligned(self):
        row=self.pair("YANG_2022","WU_2025","population")
        self.assertIn(row["status"],{"aligned","partially_aligned"})

    def test_generic_subtype_reporting_vs_explicit_list_is_not_mismatched(self):
        row=self.pair("WU_2025","FRONTIERS_2024","subtype")
        self.assertEqual(row["status"],"partially_aligned")

    def test_subtype_not_aligned_requires_documented_clinical_spectrum_difference(self):
        subtype=[r for r in self.detail if r["criterion"]=="subtype"]
        # None of the six records documents a subtype-restricted cohort; missing distributions imply partial alignment.
        self.assertTrue(all(r["status"]!="not_aligned" for r in subtype))

    def test_other_seven_criteria_are_unchanged(self):
        unchanged=[r for r in self.detail if r["criterion"] not in {"population","subtype"}]
        digest=hashlib.sha256(repr(unchanged).encode()).hexdigest()
        self.assertEqual(digest,"2bcf9b940cae8b66bead9af74340c394ebbb896fff0ce5694e9da6eb0960cdb4")


if __name__=="__main__": unittest.main()
