import sys
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from src import pipeline


class ComparabilityCorrectionTests(unittest.TestCase):
    def test_unavailable_is_not_a_mismatch_and_is_excluded(self):
        a,b=pipeline.PAPERS[0],pipeline.PAPERS[1]
        a=dict(a); b=dict(b); a["regimen"]="NR"
        va,vb,status,_=pipeline._comparison_status("regimen",a,b)
        self.assertEqual(status,"unavailable")
        self.assertEqual((va,vb),("NR",b["regimen"]))

    def test_score_denominator_uses_only_evaluable_criteria(self):
        detailed=pipeline.comparability_detail_rows()
        matrix=pipeline.comparability_rows()
        pair=next(r for r in matrix if r["study_a"]=="WU_2025" and r["study_b"]=="FRONTIERS_2024")
        statuses=[r for r in detailed if r["study_a"]==pair["study_a"] and r["study_b"]==pair["study_b"]]
        self.assertEqual(pair["evaluated_criteria"],sum(r["status"]!="unavailable" for r in statuses))

    def test_wu_and_frontiers_pcr_endpoint_is_aligned(self):
        row=next(r for r in pipeline.comparability_detail_rows() if r["study_a"]=="WU_2025" and r["study_b"]=="FRONTIERS_2024" and r["criterion"]=="endpoint_definition")
        self.assertEqual(row["status"],"aligned")


class IncrementalCorrectionTests(unittest.TestCase):
    def setUp(self): self.rows=pipeline.incremental_rows()

    def test_validation_comparison_is_primary_for_yang(self):
        row=next(r for r in self.rows if r["study_id"]=="YANG_2022" and r["comparison"].startswith("D ") and r["dataset_role"]=="internal_validation")
        self.assertEqual(row["delta_AUC"],0.068)
        self.assertEqual(row["classification"],"Suggestive")

    def test_delta_auc_values(self):
        expected={("WU_2025","G fusion vs clinical"):0.211,
                  ("WU_2025","G fusion vs radiomics"):0.055,
                  ("WU_2025","G fusion vs deep learning"):0.003,
                  ("FRONTIERS_2024","C clinical+radiomics vs clinical"):0.131,
                  ("FRONTIERS_2024","C clinical+radiomics vs radiomics"):0.165}
        for key,value in expected.items():
            row=next(r for r in self.rows if (r["study_id"],r["comparison"])==key)
            self.assertAlmostEqual(row["delta_AUC"],value,places=3)

    def test_demonstrated_requires_direct_verified_test(self):
        for row in self.rows:
            if row["classification"]=="Demonstrated":
                self.assertTrue(row["statistical_test"]!="NR")
                self.assertTrue(row["p_value"]!="NR")


if __name__=="__main__": unittest.main()
