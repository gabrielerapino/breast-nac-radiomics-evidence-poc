# Source access log

Primary full texts were accessed before consulting the external benchmark. Facts are transcribed into this project's new data records; no ovarian/adnexal findings or conclusions are carried forward.

| Study | Full text | Access state |
|---|---|---|
| Yang et al. 2022, DOI 10.3389/fonc.2022.748008 | [Frontiers full text](https://www.frontiersin.org/journals/oncology/articles/10.3389/fonc.2022.748008/full) | Full text HTML accessed. |
| Wang et al. 2025, DOI 10.1186/s12885-025-14556-4 | [BMC/Springer full text](https://bmccancer.biomedcentral.com/articles/10.1186/s12885-025-14556-4) and [PDF](https://bmccancer.biomedcentral.com/counter/pdf/10.1186/s12885-025-14556-4.pdf) | Full text HTML and PDF accessed. Some exact validation values remain REVIEW_REQUIRED. |
| Wu et al. 2025, DOI 10.3389/fonc.2025.1525285 | [Frontiers full text](https://www.frontiersin.org/journals/oncology/articles/10.3389/fonc.2025.1525285/full) | Full text HTML accessed. The article abstract and results table differ on external fusion AUC (0.891 vs 0.877); the results table value is retained and the discrepancy is marked for review. |
| Zhou et al. 2024, DOI 10.3389/fonc.2024.1485681 | [Frontiers full text](https://www.frontiersin.org/journals/oncology/articles/10.3389/fonc.2024.1485681/full) | Full text HTML accessed. |

The actual full-text files are not mirrored in this project. `source_url` and source excerpts in the structured records make each extracted claim traceable to its article section/table. Missing values remain `NR`.

The separate systematic review benchmark is not used by ingestion, extraction, validation or synthesis. The primary case-study conclusion is first stored as `outputs/synthesis_frozen.json`; the benchmark comparison is then created as a separate artifact.
