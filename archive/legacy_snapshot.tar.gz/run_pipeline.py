"""Regenerate primary evidence outputs, then (optionally) benchmark and reports."""
import json
from pathlib import Path
from src.pipeline import generate_primary, generate_benchmark_report, ROOT
from src.report import generate_report, generate_notebook

if __name__ == "__main__":
    print("Primary pipeline:", generate_primary())
    facts=json.loads((ROOT/"inputs"/"benchmark_facts.json").read_text(encoding="utf-8"))
    generate_benchmark_report(facts["summary"])
    generate_report(); generate_notebook()
    print("Benchmark comparison generated after primary synthesis freeze.")
