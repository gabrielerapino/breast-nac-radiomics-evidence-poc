"""Reusable deterministic pipeline stages: intake, extraction, review and synthesis."""
import csv
import html
import json
from itertools import combinations
from pathlib import Path
from .data import PAPERS, BENCHMARK

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs"

MATRIX_FIELDS = [
    "study_id", "authors", "year", "country", "centers", "design", "recruitment_period",
    "N_total", "train_N", "validation_N", "external_validation_N", "population", "inclusion_criteria",
    "exclusion_criteria", "subtype", "stage", "age", "regimen", "endpoint", "endpoint_definition",
    "pCR_definition", "responder_N", "nonresponder_N", "prevalence", "reference_standard", "surgery",
    "ultrasound", "SWE", "CEUS", "QUS", "scanner", "timepoints", "image_count", "segmentation",
    "radiomics_software", "initial_features", "final_features", "feature_families", "preprocessing",
    "feature_selection", "model_types", "comparator", "algorithm", "tuning", "validation_type", "source_access"
]

def write_csv(name, rows, fields=None):
    if not rows:
        return
    fields = fields or list(dict.fromkeys(k for row in rows for k in row))
    with (OUT / name).open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        writer.writeheader(); writer.writerows(rows)

def ingest():
    """Retain the source citation, access state, and source-section evidence."""
    return [{"study_id":p["study_id"], "title":p.get("title",p["study_id"]),
             "source_url":p["source_url"], "source_access":p["source_access"],
             "sections":p["quotes"]} for p in PAPERS]

def evidence_matrix():
    return [{key:p.get(key, "NR") for key in MATRIX_FIELDS} for p in PAPERS]

def performance_rows():
    fields=("AUC","CI_low","CI_high","sensitivity","specificity","accuracy","precision","recall","F1","PPV","NPV","calibration","Brier","decision_curve","threshold","p_value")
    return [{"study_id":p["study_id"], **{k:row.get(k,"NR") for k in fields}, **row} for p in PAPERS for row in p["performance"]]

def metric_rows():
    rows=[]
    metric_names=("AUC","sensitivity","specificity","accuracy","precision","recall","F1","PPV","NPV","calibration","Brier","decision_curve")
    for row in performance_rows():
        for metric in metric_names:
            rows.append({"study_id":row["study_id"],"model_id":row["model_id"],"dataset_role":row["dataset_role"],
                         "timepoint_role":row["timepoint_role"],"metric":metric,"value":row.get(metric,"NR"),
                         "CI_low":row.get("CI_low","NR") if metric=="AUC" else "NR",
                         "CI_high":row.get("CI_high","NR") if metric=="AUC" else "NR",
                         "source_section":row.get("source_section","NR"),"source_table":row.get("source_table","NR"),
                         "source_identifier":row.get("source_identifier","NR")})
    return rows

def provenance_rows():
    rows=[]
    for p in PAPERS:
        quote_names=set(p["quotes"])
        for variable in MATRIX_FIELDS:
            if variable in quote_names or variable=="study_id": continue
            section=("Methods" if variable in {"design","recruitment_period","train_N","validation_N","inclusion_criteria","exclusion_criteria","reference_standard","surgery","ultrasound","SWE","CEUS","scanner","timepoints","segmentation","radiomics_software","initial_features","feature_selection","algorithm"} else "Results/Methods")
            rows.append({"study_id":p["study_id"],"variable":variable,"value":p.get(variable,"NR"),"source_section":section,
                         "source_table":"NR","source_excerpt":"","source_identifier":p["source_url"]})
        for variable,e in p["quotes"].items():
            rows.append({"study_id":p["study_id"],"variable":variable,
                         "value":p.get(variable,"NR"),"source_section":e.get("section","NR"),
                         "source_table":e.get("table","NR"),"source_excerpt":e.get("excerpt",""),
                         "source_identifier":p["source_url"]})
        for m in p["performance"]:
            if m.get("AUC") not in (None,"NR"):
                rows.append({"study_id":p["study_id"],"variable":f'AUC:{m["model_id"]}:{m["dataset_role"]}',
                             "value":m["AUC"],"source_section":m.get("source_section","NR"),
                             "source_table":m.get("source_table","NR"),"source_excerpt":p["quotes"].get("performance",{}).get("excerpt",""),
                             "source_identifier":m.get("source_identifier",p["source_url"])})
    return rows

def endpoint_rows():
    out=[]
    for p in PAPERS:
        endpoint=p["endpoint"]
        out.append({"study":p["study_id"],"endpoint_name":endpoint,"endpoint_definition":p["endpoint_definition"],
                    "binary_mapping":"Responder/pCR=1; non-responder/non-pCR=0, as defined within each paper",
                    "comparable_to_pCR":"yes" if endpoint=="pCR / non-pCR" else "no",
                    "notes":"Do not treat this binary outcome as equivalent across studies."})
    return out

def timepoint_rows():
    return [{"study":p["study_id"],"timepoints_reported":p["timepoints"],
             "model_roles":"; ".join(sorted({m["timepoint_role"] for m in p["performance"]})),
             "notes":"AUCs from baseline, early-treatment, delta, and longitudinal models are not directly interchangeable."} for p in PAPERS]

COMPARISONS = ["A radiomics vs clinical-only", "B radiomics vs conventional ultrasound", "C combined vs clinical-only",
               "D early vs baseline radiomics", "E delta vs baseline radiomics", "F radiomics+DL vs radiomics-only", "G fusion vs components"]

def incremental_rows():
    """Explicit, dataset-matched contrasts; use the highest-priority available role."""
    rows=[]
    def model(study, model_id, role):
        return next((m for m in next(p for p in PAPERS if p["study_id"]==study)["performance"]
                     if m["model_id"]==model_id and m["dataset_role"]==role),None)
    def add(study, comparison, a_id, b_id, role, classification, test="NR", pvalue="NR", reason="", source=None):
        a,b=model(study,a_id,role),model(study,b_id,role)
        auc_a=a.get("AUC","NR") if a else "NR"; auc_b=b.get("AUC","NR") if b else "NR"
        try: delta=round(float(str(auc_a).replace("~",""))-float(str(auc_b).replace("~","")),3)
        except (ValueError,TypeError): delta="NR"
        if a and b and delta!="NR" and delta<=0 and classification in {"Suggestive","Demonstrated"}:
            classification="Not demonstrated"
        tp=a.get("timepoint_role","NR") if a else "NR"
        why=reason or f"Same {role} set: {a_id} AUC={auc_a} versus {b_id} AUC={auc_b}; ΔAUC={delta}."
        rows.append({"study_id":study,"comparison":comparison,"model_a":a_id,"model_b":b_id,
                     "dataset_role":role,"timepoint_role":tp,"auc_a":auc_a,"auc_b":auc_b,"delta_AUC":delta,
                     "statistical_test":test,"p_value":pvalue,"classification":classification,
                     "reason":why,"source":source or next(p["source_url"] for p in PAPERS if p["study_id"]==study)})
    # Yang: validation rows take precedence; the reported p=.086 is for training, not this validation contrast.
    add("YANG_2022","D early vs baseline radiomics","RS2","RS1","internal_validation","Suggestive",
        reason="Early-treatment radiomics had higher AUC on the same internal-validation set (ΔAUC=0.068); a direct validation-set test was not verified. Training DeLong p=.173 is not transferred to this validation contrast.")
    add("YANG_2022","D early vs baseline radiomics (training secondary)","RS2","RS1","training","Indeterminate",
        reason="Training AUCs are secondary because the same contrast is available in internal validation; no direct training pairwise test is used as the primary result.")
    add("YANG_2022","E delta vs baseline radiomics","Delta RS","RS1","internal_validation","Not demonstrated",
        reason="Delta radiomics did not improve on baseline on the same internal-validation set (ΔAUC=-0.011). The reported DeLong p=.086 concerns the training comparison and is not treated as validation evidence.")
    # Preserve the reported training test as a clearly secondary record because user asked to retain this finding.
    add("YANG_2022","E delta vs baseline radiomics (training secondary)","Delta RS","RS1","training","Not demonstrated","DeLong","0.086",
        "Training comparison: Δ RS AUC 0.743 vs RS1 0.722; reported DeLong p=.086. Validation comparison is primary.")
    # Wu external validation: only the clinic benchmark has a traceable tabulated p value.
    add("WU_2025","G fusion vs clinical","Fusion","Clinical","external_validation","Demonstrated","DeLong","0.003",
        "External-validation AUC improved by 0.211; Table 2 reports DeLong p=.003 with Clinic as benchmark.")
    add("WU_2025","G fusion vs radiomics","Fusion","Radiomics","external_validation","Suggestive",
        reason="Fusion exceeded radiomics on the same external-validation set (ΔAUC=0.055). Article describes superiority, but a pair-specific external DeLong result is not verifiable from the reported clinic-benchmark table.")
    add("WU_2025","G fusion vs deep learning","Fusion","Deep learning","external_validation","Suggestive",
        reason="Fusion exceeded deep learning on the same external-validation set (ΔAUC=0.003); a pair-specific external DeLong result is not verifiable from the reported clinic-benchmark table.")
    # Wang: direct DeLong validation contrasts exist, but exact validation AUCs remain untranscribed.
    for comp,other,pv in [("C combined vs clinical","Model_Clinic","0.006"),
                           ("G combined vs radiomics","Model_RSA","0.042")]:
        add("WANG_2025",comp,"Model_Combined",other,"internal_validation","Demonstrated","DeLong",pv,
            f"The full text reports a direct validation DeLong comparison (p={pv}); the exact validation AUC pair is not available in the extracted record, so ΔAUC remains NR and REVIEW_REQUIRED remains.")
    # Frontiers 2024: validation-specific DeLong significance is stated, while exact p values are not.
    add("FRONTIERS_2024","C clinical+radiomics vs clinical","GBM clinical+radiomics","GBM clinical","internal_validation","Demonstrated","DeLong","significant; exact p NR",
        "Combined clinical+radiomics performance exceeded the clinical-only model on the same internal validation set (ΔAUC=0.131); the paper reports a statistically significant validation DeLong comparison, but no numeric p value was identified.")
    add("FRONTIERS_2024","C clinical+radiomics vs radiomics","GBM clinical+radiomics","GBM radiomics","internal_validation","Demonstrated","DeLong","significant; exact p NR",
        "Combined clinical+radiomics performance exceeded radiomics-only on the same internal validation set (ΔAUC=0.165); the paper reports a statistically significant validation DeLong comparison, but no numeric p value was identified.")
    return rows

def methodological_rows():
    return [{"study_id":p["study_id"],"consideration":k,"status":v,"evidence":"See evidence_provenance.csv and source-linked record."} for p in PAPERS for k,v in p["methodology"].items()]

def validation_rows():
    checks=[]
    for p in PAPERS:
        critical=["N_total","endpoint_definition","pCR_definition","responder_N","prevalence","train_N","validation_N","validation_type","comparator","timepoints","initial_features","feature_selection"]
        for k in critical:
            v=p.get(k,"NR")
            if v=="NR" or "review" in str(v).lower() or "unclear" in str(v).lower(): status="REVIEW_REQUIRED"; independent="Not resolved independently; second-pass check flags source ambiguity or missing value."
            else: status="MATCH"; independent=str(v)
            checks.append({"study_id":p["study_id"],"field":k,"extractor_value":v,"validator_value":independent,"status":status})
        for m in p["performance"]:
            review=(p["study_id"]=="WANG_2025" and "~" in str(m["AUC"])) or (p["study_id"]=="WU_2025" and m["model_id"]=="Fusion" and m["dataset_role"]=="external_validation")
            validator="0.891 in abstract vs 0.877 in Table 2" if review and p["study_id"]=="WU_2025" else ("approximately 0.90; exact table value not transcribed" if review else m.get("AUC"))
            checks.append({"study_id":p["study_id"],"field":f'AUC:{m["model_id"]}:{m["dataset_role"]}',"extractor_value":m["AUC"],"validator_value":validator,"status":"REVIEW_REQUIRED" if review else "MATCH"})
    return checks

COMPARABILITY_CRITERIA=("endpoint_definition","regimen","timepoint","imaging_modality","radiomics_strategy","comparator","validation","population","subtype")

def _availability(value):
    return value is not None and str(value).strip().lower() not in {"","nr","not reported","unclear","unknown","none"}

def _comparison_status(criterion,a,b):
    fields={"endpoint_definition":"endpoint","regimen":"regimen","timepoint":"timepoints","imaging_modality":"ultrasound",
            "radiomics_strategy":"model_types","comparator":"comparator","validation":"validation_type","population":"population","subtype":"subtype"}
    va,vb=a.get(fields[criterion],"NR"),b.get(fields[criterion],"NR")
    if not _availability(va) or not _availability(vb): return va,vb,"unavailable","At least one study does not report enough information for this criterion; it is excluded from the score."
    x,y=str(va).lower(),str(vb).lower()
    if criterion=="endpoint_definition":
        if x==y or ("pcr" in x and "pcr" in y and "mhr" not in x+y and "recist" not in x+y): return va,vb,"aligned","Both studies target pathological complete response versus non-pCR; wording differs but endpoint category is shared."
        return va,vb,"not_aligned","The response definitions differ (e.g. pCR, MHR, or imaging RECIST response); they are not treated as equivalent."
    if criterion=="regimen":
        if x==y:return va,vb,"aligned","Treatment regimen descriptions match."
        if ("anthracycline" in x or "ac-" in x or "ac/" in x) and ("anthracycline" in y or "ac-" in y or "ac/" in y): return va,vb,"partially_aligned","Both include anthracycline-based regimens, but specific regimen composition/cycles differ or are incompletely reported."
        return va,vb,"partially_aligned","Both concern neoadjuvant systemic therapy, but regimen composition differs or is not sufficiently aligned."
    if criterion=="timepoint":
        if x==y:return va,vb,"aligned","Imaging/model timepoint descriptions match."
        baseline_a="pretreatment" in x or "baseline" in x; baseline_b="pretreatment" in y or "baseline" in y
        if baseline_a and baseline_b:return va,vb,"partially_aligned","Both include baseline imaging, but one or both also use early, midpoint, delta, or longitudinal information."
        return va,vb,"not_aligned","Imaging timepoint roles differ without an explicitly shared primary timepoint."
    if criterion=="imaging_modality":
        if x==y:return va,vb,"aligned","Ultrasound modality descriptions match."
        if "b-mode" in x and "b-mode" in y:return va,vb,"partially_aligned","Both include B-mode ultrasound; additional modalities differ (e.g. SWE/CEUS/Doppler)."
        return va,vb,"partially_aligned","Both use ultrasound, but acquisition modality components differ."
    if criterion in {"radiomics_strategy","comparator"}:
        aa=set(t for t in ("radiomics","clinical","deep-learning","fusion","combined","delta","early") if t in x)
        bb=set(t for t in ("radiomics","clinical","deep-learning","fusion","combined","delta","early") if t in y)
        overlap=aa&bb
        if x==y:return va,vb,"aligned","Model/comparator roles match."
        if overlap:return va,vb,"partially_aligned",f"Shared role(s) {', '.join(sorted(overlap))}; model composition or available comparator set differs."
        return va,vb,"not_aligned","Model strategy/comparator roles do not overlap sufficiently."
    if criterion=="validation":
        if x==y:return va,vb,"aligned","Validation designs match."
        if ("internal" in x and "internal" in y):return va,vb,"partially_aligned","Both use internal validation, but split/cohort design differs."
        return va,vb,"not_aligned","Validation setting differs (e.g. internal holdout versus external center validation)."
    # Population and subtype are descriptions; require meaningful overlap, not string identity.
    if x==y:return va,vb,"aligned",f"{criterion.capitalize()} descriptions match."
    tokens=lambda s:set(t for t in s.replace("/", " ").replace(","," ").replace(";"," ").split() if len(t)>3 and t not in {"patients","breast","cancer","study","with","from","were","aged"})
    common=tokens(x)&tokens(y)
    if criterion=="subtype" and ("subtype" in x or "subtype" in y):
        if any(q in x and q in y for q in ("luminal","her2","triple-negative","triple negative")):return va,vb,"partially_aligned","Subtype categories overlap, but reporting granularity or subtype distribution differs."
    if len(common)>=2:return va,vb,"partially_aligned",f"Descriptions share characteristics ({', '.join(sorted(common)[:4])}), but populations are not identical."
    return va,vb,"not_aligned",f"Reported {criterion} characteristics differ; no sufficient shared profile was identified."

def comparability_detail_rows():
    rows=[]
    for a,b in combinations(PAPERS,2):
        for c in COMPARABILITY_CRITERIA:
            va,vb,status,reason=_comparison_status(c,a,b)
            rows.append({"study_a":a["study_id"],"study_b":b["study_id"],"criterion":c,"value_a":va,"value_b":vb,"status":status,"reason":reason})
    return rows

def comparability_rows():
    detailed=comparability_detail_rows(); rows=[]
    for a,b in combinations(PAPERS,2):
        pair=[r for r in detailed if r["study_a"]==a["study_id"] and r["study_b"]==b["study_id"]]
        evaluated=[r for r in pair if r["status"]!="unavailable"]
        points=sum({"aligned":1,"partially_aligned":.5,"not_aligned":0}[r["status"]] for r in evaluated)
        score=round(points/len(evaluated),3) if evaluated else "NR"
        rating="high" if score!="NR" and score>=.75 else "moderate" if score!="NR" and score>=.50 else "low"
        reason=f"Alignment {points:g}/{len(evaluated)} evaluable criteria (score={score}); unavailable criteria excluded. Weights: aligned=1, partially_aligned=0.5, not_aligned=0."
        rows.append({"study_a":a["study_id"],"study_b":b["study_id"],"alignment_score":score,"evaluated_criteria":len(evaluated),"rating":rating,"reason":reason})
    return rows

def assess_poolability():
    """Require a shared endpoint plus radiomics timepoint and validation-role alignment."""
    groups={}
    for paper in PAPERS:
        groups.setdefault(paper["endpoint"],[]).append(paper)
    eligible=[group for group in groups.values() if len(group)>=2]
    if not eligible:
        return "not justified", "No endpoint-defined subgroup contains at least two studies."
    for group in eligible:
        roles=[]
        for paper in group:
            roles.append({m["timepoint_role"] for m in paper["performance"] if "radiomics" in m["model_type"]})
        shared_timepoints=set.intersection(*roles) if roles and all(roles) else set()
        shared_validation=set.intersection(*[{m["dataset_role"] for m in p["performance"] if "radiomics" in m["model_type"]} for p in group])
        if shared_timepoints and shared_validation:
            return "partially justified", "A narrow endpoint/timepoint/validation subgroup is present; any future quantitative pooling would still need aligned algorithms and denominators. No pooling executed in this run."
    return "not justified", "The two pCR studies form an endpoint-aligned subgroup, but their radiomics timepoint roles differ (pretreatment baseline vs pretreatment+midpoint longitudinal), as do validation settings (internal holdout vs internal and external center validation). No sufficiently aligned subgroup remains for quantitative pooling; no forest plot or meta-analysis was produced."

def freeze_synthesis():
    poolability,poolability_reason=assess_poolability()
    result={"research_question":"Does ultrasound-based radiomics provide incremental predictive value beyond clinical and conventional ultrasound models?",
      "primary_studies":[p["study_id"] for p in PAPERS],"primary_synthesis_frozen":True,"benchmark_consulted":False,
      "poolability":poolability,"poolability_reason":poolability_reason,"pooling_performed":False,"forest_plot_produced":False,
      "key_message":"High predictive performance does not by itself demonstrate incremental value.",
      "synthesis":["All four reports provide predictive performance, but outcome definitions and imaging strategies differ.","Yang 2022 targets an imaging-defined RECIST response, not pCR; its delta score was not significantly better than the baseline or early score in the reported comparison.","Wang 2025 reports Miller–Payne MHR (G4–G5), not pCR; its validation combined-model AUC is reported approximately and remains flagged for exact-value review.","The two pCR studies report promising combined-model performance, but the 2024 study's internal validation AUC is lower than training; Wu 2025 uses pretreatment plus midpoint imaging and has an abstract/table discrepancy for external fusion AUC.","Comparisons do not establish a consistent incremental contribution of radiomics beyond a conventional ultrasound/clinical model across all four studies."],
      "review_required_count":sum(x["status"]=="REVIEW_REQUIRED" for x in validation_rows()),
      "limitations":["Four selected studies only; not an exhaustive systematic review.","Several extraction values and timing details are ambiguous or approximate and remain flagged.","No pooling was run; qualitative poolability judgment is not a meta-analysis." ]}
    (OUT/"synthesis_frozen.json").write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding="utf-8")
    return result

def _svg(name,title,rows,label,value,scale=1.0):
    if name=="incremental_value.svg":
        height=max(150,55+len(rows)*30); parts=[f'<svg xmlns="http://www.w3.org/2000/svg" width="1000" height="{height}"><rect width="100%" height="100%" fill="#fbfaf7"/><text x="18" y="25" font-size="17" font-family="sans-serif" font-weight="bold">{html.escape(title)}</text><line x1="770" y1="40" x2="770" y2="{height-8}" stroke="#777" stroke-dasharray="4 3"/><text x="770" y="39" text-anchor="middle" font-size="9">0</text>']
        for i,row in enumerate(rows):
            y=50+i*30; txt=html.escape(str(label(row)))
            try: v=float(str(value(row)).replace("~","")); w=min(300,abs(v)*1600); x=770-w if v<0 else 770; color="#b96a61" if v<0 else "#477c78"
            except ValueError: v=None; w=0; x=770; color="#aaa"
            parts += [f'<text x="15" y="{y+14}" font-size="10" font-family="sans-serif">{txt}</text>',f'<rect x="{x:.1f}" y="{y}" width="{w:.1f}" height="17" fill="{color}"/>',f'<text x="{min(970,x+w+5):.1f}" y="{y+13}" font-size="10">{v if v is not None else "NR"}</text>']
        parts.append('</svg>'); (ROOT/"figures"/name).write_text("\n".join(parts),encoding="utf-8"); return
    height=max(150,55+len(rows)*28); parts=[f'<svg xmlns="http://www.w3.org/2000/svg" width="1000" height="{height}"><rect width="100%" height="100%" fill="#fbfaf7"/><text x="18" y="25" font-size="17" font-family="sans-serif" font-weight="bold">{html.escape(title)}</text>']
    for i,row in enumerate(rows):
        y=48+i*28; txt=html.escape(str(label(row)))
        try: v=float(str(value(row)).replace("~","")); w=max(0,min(1,v))*350
        except ValueError: v=None; w=0
        parts += [f'<text x="15" y="{y+14}" font-size="10" font-family="sans-serif">{txt}</text>',f'<rect x="620" y="{y}" width="{w:.1f}" height="17" fill="#477c78"/>',f'<text x="{625+w:.1f}" y="{y+13}" font-size="10">{v if v is not None else "NR"}</text>']
    parts.append('</svg>'); (ROOT/"figures"/name).write_text("\n".join(parts),encoding="utf-8")

def generate_primary():
    OUT.mkdir(exist_ok=True); (ROOT/"figures").mkdir(exist_ok=True)
    matrix=evidence_matrix(); perf=performance_rows(); prov=provenance_rows(); inc=incremental_rows(); pairs=comparability_rows(); checks=validation_rows()
    write_csv("evidence_matrix.csv",matrix,MATRIX_FIELDS); write_csv("performance_wide.csv",perf); write_csv("performance_table.csv",metric_rows())
    write_csv("evidence_provenance.csv",prov)
    write_csv("incremental_value.csv",inc,["study_id","comparison","model_a","model_b","dataset_role","timepoint_role","auc_a","auc_b","delta_AUC","statistical_test","p_value","classification","reason","source"])
    write_csv("endpoint_mapping.csv",endpoint_rows())
    write_csv("timepoint_mapping.csv",timepoint_rows())
    write_csv("comparability_matrix.csv",pairs,["study_a","study_b","alignment_score","evaluated_criteria","rating","reason"])
    write_csv("comparability_detailed.csv",comparability_detail_rows(),["study_a","study_b","criterion","value_a","value_b","status","reason"])
    write_csv("methodological_considerations.csv",methodological_rows()); write_csv("validation_checks.csv",checks)
    write_csv("study_design_overview.csv",[{k:p.get(k,"NR") for k in ("study_id","year","design","centers","N_total","train_N","validation_N","external_validation_N","validation_type")} for p in PAPERS])
    (OUT/"ingestion_records.json").write_text(json.dumps(ingest(),indent=2,ensure_ascii=False),encoding="utf-8")
    (OUT/"structured_studies.json").write_text(json.dumps(PAPERS,indent=2,ensure_ascii=False),encoding="utf-8")
    freeze_synthesis()
    _svg("auc_by_model.svg","Reported AUC by model and dataset role",[m for m in perf if m.get("AUC")!="NR"],lambda m:f"{m['study_id']} · {m['model_id']} · {m['dataset_role']} · {m['timepoint_role']}",lambda m:m["AUC"])
    _svg("timepoint_performance.svg","Baseline, early-treatment and delta models (descriptive)",[m for m in perf if m.get("AUC")!="NR"],lambda m:f"{m['study_id']} · {m['timepoint_role']} · {m['model_id']}",lambda m:m["AUC"])
    _svg("incremental_value.svg","Matched incremental comparisons: AUC difference (descriptive)",[r for r in inc if r["delta_AUC"]!="NR"],lambda r:f"{r['study_id']} · {r['comparison']} · {r['classification']}",lambda r:r["delta_AUC"])
    _svg("study_design_overview.svg","Study size by cohort role",[{"study":p["study_id"],"N":p["N_total"]} for p in PAPERS],lambda r:r["study"],lambda r:float(r["N"])/700)
    # Pairwise similarity matrix as a compact SVG, with neutral colors and explicit rating labels.
    ids=[p["study_id"] for p in PAPERS]; lookup={}
    for r in pairs: lookup[(r["study_a"],r["study_b"])]=r["rating"]
    colors={"high":"#74a98a","moderate":"#e7c875","low":"#d98b83"}
    s=['<svg xmlns="http://www.w3.org/2000/svg" width="650" height="320"><rect width="100%" height="100%" fill="#fbfaf7"/><text x="10" y="20" font-size="16">Pairwise comparability (qualitative)</text>']
    for i,a in enumerate(ids):
        s.append(f'<text x="8" y="{65+i*55}" font-size="10">{a}</text>')
        for j,b in enumerate(ids):
            if j<=i: continue
            rate=lookup.get((a,b),lookup.get((b,a),"low")); x=160+j*100; y=42+i*55
            s.append(f'<rect x="{x}" y="{y}" width="90" height="38" fill="{colors[rate]}"/><text x="{x+45}" y="{y+23}" text-anchor="middle" font-size="10">{rate}</text>')
    s.append('</svg>'); (ROOT/"figures"/"pairwise_comparability.svg").write_text("\n".join(s),encoding="utf-8")
    flow=['<svg xmlns="http://www.w3.org/2000/svg" width="1100" height="210"><rect width="100%" height="100%" fill="#fbfaf7"/>']
    for i,txt in enumerate(["Study","Timepoint","Model family","Validation role","Outcome"]):
        x=20+i*215; flow.append(f'<rect x="{x}" y="60" width="170" height="70" rx="8" fill="#e8efeb" stroke="#477c78"/><text x="{x+85}" y="100" text-anchor="middle" font-size="15">{txt}</text>')
        if i<4: flow.append(f'<path d="M{x+175} 95h35" stroke="#555" stroke-width="2"/>')
    flow.append('</svg>'); (ROOT/"figures"/"workflow.svg").write_text("\n".join(flow),encoding="utf-8")
    return {"studies":len(PAPERS),"performance_rows":len(perf),"provenance_rows":len(prov),"review_required":sum(x["status"]=="REVIEW_REQUIRED" for x in checks)}

def generate_benchmark_report(benchmark_facts):
    frozen=json.loads((OUT/"synthesis_frozen.json").read_text(encoding="utf-8"))
    if not frozen.get("primary_synthesis_frozen"):
        raise RuntimeError("Freeze primary synthesis before consulting benchmark")
    body=("# External benchmark comparison\n\n"
          "The primary evidence synthesis was frozen in `synthesis_frozen.json` before this review was consulted. This comparison is separate and does not alter the frozen primary synthesis.\n\n"
          f"Benchmark: [{BENCHMARK['title']}]({BENCHMARK['url']}) ({BENCHMARK['year']}; DOI {BENCHMARK['doi']}; PMID {BENCHMARK['pmid']}).\n\n"
          f"{benchmark_facts}\n\n"
          "The review concerns a broader set of ultrasound radiomics studies and reports pooled summaries; the four-study case study intentionally distinguishes pCR from imaging-defined response and MHR, and separates baseline, early and delta timepoints. Therefore numerical estimates are not directly comparable. The benchmark is methodologically informative but does not change the frozen synthesis.\n")
    (OUT/"benchmark_comparison.md").write_text(body,encoding="utf-8")
    (OUT/"benchmark_state.json").write_text(json.dumps({"benchmark_consulted":True,"primary_freeze_sha256":__import__("hashlib").sha256((OUT/"synthesis_frozen.json").read_bytes()).hexdigest()},indent=2),encoding="utf-8")

