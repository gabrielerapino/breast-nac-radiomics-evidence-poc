"""Self-contained HTML and notebook generation using only the Python standard library."""
import csv, html, json
from pathlib import Path
from . import pipeline as p

ROOT=p.ROOT; OUT=p.OUT
def read_csv(name):
    with (OUT/name).open(encoding="utf-8",newline="") as f: return list(csv.DictReader(f))

def generate_report():
    matrix=read_csv("evidence_matrix.csv"); perf=read_csv("performance_wide.csv"); inc=read_csv("incremental_value.csv")
    pairs=read_csv("comparability_matrix.csv"); checks=read_csv("validation_checks.csv"); meth=read_csv("methodological_considerations.csv")
    frozen=json.loads((OUT/"synthesis_frozen.json").read_text(encoding="utf-8"))
    def table(rows,cols):
        head="".join(f"<th>{html.escape(c)}</th>" for c in cols)
        body="".join("<tr>"+"".join(f"<td>{html.escape(str(r.get(c,'NR')))}</td>" for c in cols)+"</tr>" for r in rows)
        return f"<div class='scroll'><table><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table></div>"
    sections=[]
    sections.append("<h1>Agentic evidence synthesis: ultrasound radiomics in breast NAC</h1><h2>1. Research question</h2><p class='lead'>Does ultrasound-based radiomics provide incremental predictive value beyond clinical and conventional ultrasound models?</p><p class='key'>High predictive performance does not by itself demonstrate incremental value.</p>")
    sections.append("<h2>2. Selected studies</h2>"+table(matrix,["study_id","authors","year","N_total","train_N","validation_N","external_validation_N"]))
    sections.append("<h2>3. Source access</h2>"+table(matrix,["study_id","source_access"])+"<p>Source links are recorded in <code>evidence_provenance.csv</code>; four full texts were accessed. Source access is not equivalent to independent verification of every extracted field.</p>")
    sections.append("<h2>4. Clinical endpoint definitions</h2>"+table(read_csv("endpoint_mapping.csv"),["study","endpoint_name","endpoint_definition","comparable_to_pCR","notes"]))
    sections.append("<h2>5. Imaging timepoints</h2>"+table(read_csv("timepoint_mapping.csv"),["study","timepoints_reported","model_roles","notes"]))
    sections.append("<h2>6. Evidence extraction</h2>"+table(matrix,["study_id","population","regimen","ultrasound","segmentation","radiomics_software","initial_features","final_features","model_types","comparator","algorithm","validation_type"]))
    sections.append("<h2>7. Comparative evidence and workflow</h2><img src='../figures/workflow.svg' alt='Study to outcome workflow'>"+table(matrix,["study_id","model_types","validation_type","endpoint","timepoints"]))
    sections.append("<h2>8. Performance comparison</h2><p>Absolute performance is shown with model and dataset role. Training, internal validation, external validation, baseline, early-treatment, delta and longitudinal estimates must be interpreted separately.</p><img src='../figures/study_design_overview.svg' alt='Study design overview'><img src='../figures/auc_by_model.svg' alt='AUC chart'><img src='../figures/timepoint_performance.svg' alt='AUC by timepoint'>"+table(perf,["study_id","model_id","model_type","dataset_role","timepoint_role","AUC","CI_low","CI_high","sensitivity","specificity","accuracy","precision","recall","F1","PPV","NPV","calibration","Brier","decision_curve","threshold","p_value"]))
    sections.append("<h2>9. Incremental value</h2><p>Matched comparisons prioritize external validation, then internal validation, test and training. Demonstrated requires an appropriate direct statistical comparison; numerical AUC differences alone are suggestive at most. NR values remain unquantified.</p><img src='../figures/incremental_value.svg' alt='Incremental value comparison'>"+table(inc,["study_id","comparison","model_a","model_b","dataset_role","timepoint_role","auc_a","auc_b","delta_AUC","statistical_test","p_value","classification","reason","source"]))
    sections.append("<h2>10. Methodological considerations</h2>"+table(meth,["study_id","consideration","status","evidence"]))
    sections.append("<h2>11. Cross-study comparability</h2><p>Exactly nine criteria are assessed. Each is labeled aligned, partially_aligned, not_aligned or unavailable. Unavailable criteria are excluded from the denominator; weights are 1, 0.5 and 0 for the first three statuses. Ratings use high ≥0.75, moderate ≥0.50 and low &lt;0.50.</p><img src='../figures/pairwise_comparability.svg' alt='Comparability matrix'>"+table(pairs,["study_a","study_b","alignment_score","evaluated_criteria","rating","reason"])+"<h3>Criterion-level assessment</h3>"+table(read_csv("comparability_detailed.csv"),["study_a","study_b","criterion","value_a","value_b","status","reason"]))
    sections.append("<h2>12. Poolability decision</h2><p><b>"+html.escape(frozen["poolability"])+"</b>: "+html.escape(frozen["poolability_reason"])+"</p>")
    sections.append("<h2>13. Final synthesis</h2><ul>"+"".join(f"<li>{html.escape(x)}</li>" for x in frozen["synthesis"])+"</ul><h3>Validation checks and human review</h3>"+table([x for x in checks if x["status"]=="REVIEW_REQUIRED"],["study_id","field","extractor_value","validator_value","status"]))
    benchmark=(OUT/"benchmark_comparison.md").read_text(encoding="utf-8") if (OUT/"benchmark_comparison.md").exists() else "Benchmark comparison not generated yet."
    sections.append("<h2>14. Benchmark comparison</h2><p>Separate external review, consulted after the primary synthesis freeze:</p><pre>"+html.escape(benchmark)+"</pre>")
    sections.append("<h2>15. Limitations of the AI pipeline</h2><p>The four studies were protocol-selected, not found through a comprehensive systematic search. Some fields remain not reported or require human review. Automated checks identify ambiguity but cannot adjudicate source conflicts or replace clinical and methodological appraisal. No patient-level data or new model fitting was performed.</p>")
    doc="<!doctype html><html lang='en'><meta charset='utf-8'><title>Breast NAC ultrasound radiomics synthesis</title><style>body{font:15px/1.5 system-ui,sans-serif;max-width:1200px;margin:32px auto;padding:0 20px;color:#182420;background:#fbfaf7}h1,h2{color:#245b53}h2{margin-top:2.2em;border-bottom:1px solid #ccd7d1}table{border-collapse:collapse;width:100%;font-size:12px}th,td{border:1px solid #d7dfda;padding:7px;vertical-align:top;text-align:left}th{background:#e8efeb;position:sticky;top:0}.scroll{overflow:auto;max-height:570px}.key{padding:15px;background:#e8efeb;font-size:18px;font-weight:650}.lead{font-size:19px}img{max-width:100%;display:block;margin:16px auto}</style><body>"+"\n".join(sections)+"</body></html>"
    (OUT/"evidence_synthesis_report.html").write_text(doc,encoding="utf-8")

def update_focus_sections():
    """Refresh only incremental-value/comparability sections in existing report and notebook."""
    import re
    report_path=OUT/"evidence_synthesis_report.html"
    doc=report_path.read_text(encoding="utf-8")
    def table(rows,cols):
        head="".join(f"<th>{html.escape(c)}</th>" for c in cols)
        body="".join("<tr>"+"".join(f"<td>{html.escape(str(r.get(c,'NR')))}</td>" for c in cols)+"</tr>" for r in rows)
        return f"<div class='scroll'><table><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table></div>"
    inc=read_csv("incremental_value.csv"); pairs=read_csv("comparability_matrix.csv"); detail=read_csv("comparability_detailed.csv")
    inc_html=("<h2>9. Incremental value</h2><p>Matched comparisons prioritize external validation, then internal validation, test and training. Demonstrated requires an appropriate direct statistical comparison; numerical AUC differences alone are suggestive at most. NR values remain unquantified.</p>"
              "<img src='../figures/incremental_value.svg' alt='Incremental value comparison'>"+
              table(inc,["study_id","comparison","model_a","model_b","dataset_role","timepoint_role","auc_a","auc_b","delta_AUC","statistical_test","p_value","classification","reason","source"]))
    comp_html=("<h2>11. Cross-study comparability</h2><p>Exactly nine criteria are assessed. Each is labeled aligned, partially_aligned, not_aligned or unavailable. Unavailable criteria are excluded from the denominator; weights are 1, 0.5 and 0 for the first three statuses. Ratings use high ≥0.75, moderate ≥0.50 and low &lt;0.50.</p>"
               "<img src='../figures/pairwise_comparability.svg' alt='Comparability matrix'>"+
               table(pairs,["study_a","study_b","alignment_score","evaluated_criteria","rating","reason"])+"<h3>Criterion-level assessment</h3>"+
               table(detail,["study_a","study_b","criterion","value_a","value_b","status","reason"]))
    doc,n1=re.subn(r"<h2>9\. Incremental value</h2>.*?(?=<h2>10\.)",inc_html,doc,count=1,flags=re.S)
    doc,n2=re.subn(r"<h2>11\. Cross-study comparability</h2>.*?(?=<h2>12\.)",comp_html,doc,count=1,flags=re.S)
    if n1!=1 or n2!=1: raise ValueError("Could not isolate exactly the two requested HTML report sections")
    report_path.write_text(doc,encoding="utf-8")
    notebook_path=ROOT/"agentic_evidence_synthesis.ipynb"
    nb=json.loads(notebook_path.read_text(encoding="utf-8"))
    replacements={"## 10. Incremental value":"## 10. Incremental value\n\nValidation-priority matched contrasts are exported in `outputs/incremental_value.csv`. External validation precedes internal validation, test and training; direct statistical evidence is required for Demonstrated, and AUC alone is not proof of added value.",
                  "## 11. Comparability":"## 11. Comparability\n\nNine named criteria are rated aligned, partially_aligned, not_aligned or unavailable. Unavailable criteria are excluded from the score denominator; aligned=1, partially aligned=0.5 and not aligned=0. Pair-specific details are in `outputs/comparability_detailed.csv`."}
    changed=0
    for cell in nb["cells"]:
        if cell.get("cell_type")=="markdown":
            src="".join(cell.get("source",[]))
            for key,value in replacements.items():
                if src.startswith(key): cell["source"]=value.splitlines(True); changed+=1; break
    if changed!=2: raise ValueError(f"Expected to update exactly two notebook markdown cells; updated {changed}")
    notebook_path.write_text(json.dumps(nb,indent=2,ensure_ascii=False),encoding="utf-8")

def generate_notebook():
    cells=[]
    def md(s): cells.append({"cell_type":"markdown","metadata":{},"source":s.splitlines(True)})
    def code(s): cells.append({"cell_type":"code","execution_count":None,"metadata":{},"outputs":[],"source":s.splitlines(True)})
    md("# Agentic evidence synthesis: ultrasound radiomics in breast NAC\n\nReproducible walkthrough. Pipeline logic lives in importable modules; `NR` is never coerced to a numeric value.")
    sections=[("1. Research question","Does ultrasound-based radiomics provide incremental predictive value for predicting response to neoadjuvant therapy in breast cancer beyond clinical and conventional ultrasound-based models?"),("2. Why this problem matters","Early response may inform treatment decisions, but apparent discrimination and incremental value answer different questions."),("3. Selected studies","Four protocol-specified full-text open-access studies are tracked independently."),("4. Agentic workflow","Ingestion → factual extraction → validation → methodological interpretation → comparability → synthesis → benchmark. The benchmark is consulted after synthesis freeze."),("5. Structured extraction","Extracted records retain source sections, tables, short excerpts and identifiers."),("6. Endpoint harmonization","pCR, MHR and RECIST-defined responder outcomes remain distinct."),("7. Timepoint harmonization","Baseline, after two cycles, post-NAC, delta and longitudinal-combined models are separately labeled."),("8. Evidence matrix","Study-level structured fields are exported as CSV."),("9. Performance comparison","Performance is indexed by dataset role and timepoint role."),("10. Incremental value","Matched comparisons prioritize external validation, then internal validation, test and training; direct statistical evidence is required for Demonstrated."),("11. Comparability","Nine criteria receive aligned, partially_aligned, not_aligned or unavailable statuses. Unavailable criteria are excluded from the score denominator; pair-specific details are exported separately."),("12. Poolability","The pipeline evaluates potential subgroups; it does not launch a meta-analysis automatically."),("13. Final synthesis","The synthesis is frozen to JSON before benchmark review."),("14. Benchmark check","A separate review comparison is generated only after the frozen primary synthesis exists."),("15. Limitations","Four selected studies, source ambiguity and human review requirements constrain conclusions.")]
    for h,b in sections: md(f"## {h}\n\n{b}")
    code("from pathlib import Path\nimport csv, json\nfrom src.pipeline import evidence_matrix, performance_rows, incremental_rows, comparability_rows, validation_rows\nfrom src.report import read_csv\nROOT = Path.cwd()\nif not (ROOT / 'outputs').exists(): ROOT = ROOT / 'breast_nac_ultrasound_radiomics'\nprint('Project:', ROOT)")
    code("evidence_matrix()[:1]")
    code("performance_rows()[:5]")
    code("incremental_rows()[:8]")
    code("comparability_rows()")
    code("validation_rows()")
    code("json.loads((ROOT / 'outputs' / 'synthesis_frozen.json').read_text())")
    doc={"cells":cells,"metadata":{"kernelspec":{"display_name":"Python 3","language":"python","name":"python3"}},"nbformat":4,"nbformat_minor":5}
    (ROOT/"agentic_evidence_synthesis.ipynb").write_text(json.dumps(doc,indent=2,ensure_ascii=False),encoding="utf-8")

def generate_all():
    result=p.generate_primary(); generate_report(); generate_notebook(); return result
